/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete.gestion;

import paquete.clases.Pintura;

/**
 *
 * @author sebas
 */
public class GestionPintura 
{
    private Pintura[] arreglo;
    private int conta;

    public GestionPintura()
    {
        arreglo = new Pintura[10];
        conta = 0;
    }

    public Pintura[] getArreglo() {
        return arreglo;
    }

    public void setArreglo(Pintura[] arreglo) {
        this.arreglo = arreglo;
    }

    public int getConta() {
        return conta;
    }

    public void setConta(int conta) {
        this.conta = conta;
    }
    
    public void Ingresar(Pintura ref)
    {
        if(conta<arreglo.length)
        {
            arreglo[conta] = ref;
            conta++;
        }
        
        else 
        {
            System.out.println("No hay espacio");
        }
    }
    
    public String VerInfo()
    {
        String cad = "";
        for(int i=0;i<conta;i++)
        {
            cad = cad + arreglo[i].VerInfo() + "\n";
        }
        return cad;
    }
}
