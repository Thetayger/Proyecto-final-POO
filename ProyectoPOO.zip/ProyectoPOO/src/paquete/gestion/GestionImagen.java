package paquete.gestion;

import paquete.clases.Imagen;

/**
 *
 * @author user
 */
    public class GestionImagen 
{
    private Imagen[] arreglo;
    private int conta;

    public GestionImagen() 
    {
        arreglo = new Imagen[5];
        conta=0;
    }

    public Imagen[] getArreglo() {
        return arreglo;
    }

    public void setArreglo(Imagen[] arreglo) {
        this.arreglo = arreglo;
    }

    public int getConta() {
        return conta;
    }

    public void setConta(int conta) {
        this.conta = conta;
    }
    
    public void Ingresar(Imagen ref)
    {
        if(conta<arreglo.length)
        {
            arreglo[conta]=ref;
            conta++;
        }
        else
        {
            System.out.println("No hay espacio");
        }
    }
    
    public void Eliminar(int id)
    {
        for(int i=0;i<conta;i++)
        {
            if(arreglo[i].getId()==id)
            {
                for(int j=i;j<conta-1;j++)
                {
                    arreglo[j]=arreglo[j+1];
                }
                arreglo[conta-1]=null;
                conta--;
            }
        }
    }
    public void IngresarPos(int pos, Imagen ref)
    {
        if(conta<arreglo.length)
        {
            if(pos<=conta)
            {
                for(int i=conta-1;i>=pos;i--)
                {
                    arreglo[i+1]=arreglo[i];
                }
                arreglo[pos]=ref;
                conta++;
            }
        }
    }
    
    
    
}
