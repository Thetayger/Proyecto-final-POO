/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete.clases;

/**
 *
 * @author sebas
 */
public abstract class Imagen 
{
    protected int id;
    protected int fecha;
    protected float precio;
    protected float[][] dimension;
    protected int cantAlto;
    protected int cantAncho;

    public Imagen(int id, int fecha, int cantAlto, int cantAncho) {
        this.id = id;
        this.fecha = fecha;
        this.cantAlto = cantAlto;
        this.cantAncho = cantAncho;
    }

    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getFecha() {
        return fecha;
    }

    public void setFecha(int fecha) {
        this.fecha = fecha;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public float[][] getDimension() {
        return dimension;
    }

    public void setDimension(float[][] dimension) {
        this.dimension = dimension;
    }

    public int getCantAlto() {
        return cantAlto;
    }

    public void setCantAlto(int cantAlto) {
        this.cantAlto = cantAlto;
    }

    public int getCantAncho() {
        return cantAncho;
    }

    public void setCantAncho(int cantAncho) {
        this.cantAncho = cantAncho;
    }
    
    
    public abstract void CalcularDimension();
    public abstract void CalcularPrecio();

    public String VerInfo() 
    {
        return "ID: " + id + "\nFecha: " + fecha + "\nPrecio: " + precio;
    }
    
    
    
}
