/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete.clases;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author sebas
 */
public class Pintura extends Imagen implements Adicional
{

    public Pintura(int id, int fecha, int cantAlto, int cantAncho) {
        super(id, fecha, cantAlto, cantAncho);
    }

    


    @Override
    public void CalcularDimension()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese cantidad de Alto: ");
        this.cantAlto = sc.nextInt();
        System.out.println("Ingresar cantidad de Ancho: ");
        this.cantAncho = sc.nextInt(); 
        Random rand = new Random();
        for(int i=0;i<this.cantAlto;i++)
        {
            for(int j=0;j<this.cantAncho;j++)
            {
                dimension[i][j] = rand.nextInt();
            }
        } 
    }

    @Override
    public void CalcularPrecio()
    {
        this.precio = 12.12f*(this.cantAlto*this.cantAncho);
    }

    @Override
    public String VerInfo()
    {
        return super.VerInfo();
    }

    @Override
    public void CostoExtra() {
        if (this.cantAlto>10 && this.cantAncho>10)
            this.precio = this.precio + 150;
    }
}